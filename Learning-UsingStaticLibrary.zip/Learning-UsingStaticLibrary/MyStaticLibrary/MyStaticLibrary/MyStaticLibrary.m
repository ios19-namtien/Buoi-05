//
//  MyStaticLibrary.m
//  MyStaticLibrary
//
//  Created by NguyenTien on 12/3/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import "MyStaticLibrary.h"

@implementation MyStaticLibrary

float Result = 0;

-(void)plus2Number : (int)a : (int)b{
    Result = a + b;
    NSLog(@"Tong cua a va b la %3.2f", Result);
}

-(void) minus2Number : (int)a : (int)b{
    Result = a - b;
    NSLog(@"Hieu cua a va b la %3.2f", Result);
}

-(void) multiply2Number : (int)a : (int)b{
    Result = a * b;
    NSLog(@"Tich cua a va b la %3.2f", Result);
}

-(void) divide2Number : (int)a : (int)b{
    Result = a / b;
    NSLog(@"Thuong cua a va b la %3.2f", Result);
}

@end
