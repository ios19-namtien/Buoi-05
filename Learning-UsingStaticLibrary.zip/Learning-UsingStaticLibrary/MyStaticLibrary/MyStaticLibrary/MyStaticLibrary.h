//
//  MyStaticLibrary.h
//  MyStaticLibrary
//
//  Created by NguyenTien on 12/3/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import <Foundation/Foundation.h>
@interface MyStaticLibrary : NSObject

-(void) plus2Number : (int)a : (int)b;
-(void) minus2Number : (int)a : (int)b;
-(void) multiply2Number : (int)a : (int)b;
-(void) divide2Number : (int)a : (int)b;

@end