//
//  hdt_ViewController.m
//  AppUseStaticLibrary
//
//  Created by NguyenTien on 12/3/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import "hdt_ViewController.h"

@interface hdt_ViewController ()

@end

@implementation hdt_ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
    MyStaticLibrary *obj = [[MyStaticLibrary alloc]init];
    //--Tinh tong 2 so
    [obj plus2Number:5 :6];
    //--Hieu 2 so
    [obj minus2Number:10 :2];
    //--Tich 2 so
    [obj multiply2Number:3 :7];
    //--Thuong 2 so
    [obj divide2Number:15 :5];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
