//
//  hdt_ViewController.h
//  AppUseStaticLibrary
//
//  Created by NguyenTien on 12/3/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MyStaticLibrary.h"
@interface hdt_ViewController : UIViewController

@end
