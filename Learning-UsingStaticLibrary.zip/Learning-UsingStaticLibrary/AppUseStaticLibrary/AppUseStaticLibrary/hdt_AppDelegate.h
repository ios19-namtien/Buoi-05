//
//  hdt_AppDelegate.h
//  AppUseStaticLibrary
//
//  Created by NguyenTien on 12/3/13.
//  Copyright (c) 2013 NguyenTien. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface hdt_AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
